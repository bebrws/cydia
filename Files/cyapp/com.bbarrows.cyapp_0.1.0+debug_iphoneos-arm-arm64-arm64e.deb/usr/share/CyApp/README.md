The all.xml file contains all the entitlements I gave to the cycript app launcher. I know it is probably too many. You can reduce them and ldid sign the app yourself with the xml file included.
